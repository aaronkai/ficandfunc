<?php 
$flashBacktransparent		= '';
$flashBackcolor				= '281e15';
$buttonsBG					= 'd8ceb6';
$buttonsMouseOver			= 'f44365';
$buttonsMouseOut			= '281e15';
$catButtonsMouseOver		= 'd8ceb6';
$catButtonsMouseOut			= 'd8ceb6';
$catButtonsTextMouseOver	= 'f44365';
$catButtonsTextMouseOut		= '281e15';
$thumbMouseOver				= 'f44365';
$thumbMouseOut				= 'e7e1c7';
$mainTitle					= 'eeeadb';
$categoryTitle				= 'f44365';
$itemBG						= 'e7e1c7';
$itemTitle					= 'f44365';
$itemDescription			= 'e7e1c7';
?>