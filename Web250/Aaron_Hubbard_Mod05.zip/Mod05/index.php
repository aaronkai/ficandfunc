<?php
	include("../Includes/header.inc.php");
?>
<h1><a href="../index.php">Pick your poison</a></h1>
<?php
	include("../Includes/index.inc.php");
	include("../Includes/footer.inc.php");
?>
